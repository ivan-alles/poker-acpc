﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;

namespace $rootnamespace$
{
    /// <summary>
    /// Unit tests for ... 
    /// </summary>
    [TestFixture]
    public class $safeitemname$
    {
        #region Tests

        [Test]
        public void Test_()
        {
        }

        #endregion

        #region Benchmarks
        #endregion

        #region Implementation
        #endregion
    }
}
